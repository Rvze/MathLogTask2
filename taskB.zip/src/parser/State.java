package parser;

public interface State {
    char next();

    boolean hasNext();


}
