package operations;

public interface Expression {
    String toPrefixString();
}
